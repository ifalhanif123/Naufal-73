from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator
from typing import Literal

class SignupIn(BaseModel):
    email: EmailStr
    password: str = Field(min_length=10, max_length=128)
    full_name: str = Field(min_length=2, max_length=120)

class UserOut(BaseModel):
    id: int
    email: EmailStr
    full_name: str
    model_config = ConfigDict(from_attributes=True)

class TokenPair(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"

class RefreshIn(BaseModel):
    refresh_token: str = Field(min_length=20, max_length=4096)

class ItemIn(BaseModel):
    name: str = Field(min_length=1, max_length=160)
    sku: str = Field(min_length=1, max_length=80)
    quantity: int = Field(ge=0, le=10_000_000)
    unit: str = Field(default="unit", min_length=1, max_length=40)

class ItemUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=160)
    sku: str | None = Field(default=None, min_length=1, max_length=80)
    quantity: int | None = Field(default=None, ge=0, le=10_000_000)
    unit: str | None = Field(default=None, min_length=1, max_length=40)

class ItemOut(BaseModel):
    id: int
    owner_id: int
    name: str
    sku: str
    quantity: int
    unit: str
    model_config = ConfigDict(from_attributes=True)

class TransactionIn(BaseModel):
    item_id: int = Field(gt=0)
    kind: Literal["IN", "OUT"]
    quantity: int = Field(gt=0, le=1_000_000)
    note: str | None = Field(default=None, max_length=255)

class BorrowingIn(BaseModel):
    item_id: int = Field(gt=0)
    quantity: int = Field(gt=0, le=1_000_000)
    purpose: str = Field(min_length=2, max_length=255)

class BorrowingStatusIn(BaseModel):
    status: Literal["pending", "approved", "returned", "rejected"]

class ForecastIn(BaseModel):
    item_id: int = Field(gt=0)
    monthly_sales: list[float] = Field(min_length=6, max_length=120)
    horizon: int = Field(default=1, ge=1, le=6)
    notes: str | None = Field(default=None, max_length=500)
    @field_validator("monthly_sales")
    @classmethod
    def valid_sales(cls, values):
        if any(v < 0 or v > 1_000_000 for v in values):
            raise ValueError("monthly_sales values must be between 0 and 1,000,000")
        return values
