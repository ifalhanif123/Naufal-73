from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from jose import JWTError
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.core.database import get_db
from app.core.security import decode_token
from app.models import User

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/auth/login")

async def current_user(token: str = Depends(oauth2_scheme), db: AsyncSession = Depends(get_db)) -> User:
    unauthorized = HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Token tidak valid atau kedaluwarsa", headers={"WWW-Authenticate":"Bearer"})
    try:
        payload = decode_token(token)
        if payload.get("type") != "access" or not payload.get("sub"):
            raise unauthorized
        user_id = int(payload["sub"])
    except (JWTError, ValueError, TypeError):
        raise unauthorized
    user = await db.scalar(select(User).where(User.id == user_id, User.is_active.is_(True)))
    if not user:
        raise unauthorized
    return user

def assert_owner(resource, user: User):
    if resource.owner_id != user.id:
        # 404 avoids confirming another user's resource exists; document may choose 403 per lecturer's rubric.
        raise HTTPException(status_code=404, detail="Data tidak ditemukan")
