from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sklearn.ensemble import RandomForestRegressor
import numpy as np
from app.core.database import get_db
from app.dependencies import current_user
from app.models import User, Item, Prediction
from app.schemas import ForecastIn
router = APIRouter(prefix="/predictions", tags=["AI Forecast"])
@router.post("/forecast", status_code=201)
async def forecast(data: ForecastIn, db: AsyncSession=Depends(get_db), user: User=Depends(current_user)):
    item = await db.scalar(select(Item).where(Item.id == data.item_id, Item.owner_id == user.id))
    if not item: raise HTTPException(404, "Barang tidak ditemukan")
    values = np.asarray(data.monthly_sales, dtype=float)
    # Lag features: use up to the last 3 observed months; all data is numeric and bounded by Pydantic.
    lags = min(3, len(values)-2)
    X = np.array([[values[i-j] for j in range(lags, 0, -1)] for i in range(lags, len(values))], dtype=float)
    y = values[lags:]
    if len(y) < 3: raise HTTPException(422, "Minimal diperlukan 6 bulan data historis")
    model = RandomForestRegressor(n_estimators=100, random_state=42, min_samples_leaf=1)
    model.fit(X, y)
    window = list(values[-lags:])
    predicted = []
    for _ in range(data.horizon):
        x = np.array(window[-lags:], dtype=float).reshape(1, -1)
        p = max(0.0, float(model.predict(x)[0]))
        predicted.append(p); window.append(p)
    obj = Prediction(owner_id=user.id, item_id=item.id, predicted_quantity=round(predicted[-1], 2), horizon=data.horizon, notes=data.notes)
    db.add(obj); await db.commit(); await db.refresh(obj)
    return {"id": obj.id, "item_id": item.id, "item_name": item.name, "method": "RandomForestRegressor", "horizon_months": data.horizon, "predicted_quantity": obj.predicted_quantity, "forecast_path": [round(v,2) for v in predicted], "warning": "Demo baseline: validate with chronological holdout data and compare MAE/RMSE before operational decisions."}
@router.get("")
async def list_predictions(db: AsyncSession=Depends(get_db), user: User=Depends(current_user)):
    rows = await db.scalars(select(Prediction).where(Prediction.owner_id == user.id).order_by(Prediction.id.desc()).limit(100))
    return list(rows.all())
