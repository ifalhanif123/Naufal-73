from pathlib import Path
from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from app.core.config import settings
from app.dependencies import current_user
from app.models import User
router = APIRouter(prefix="/ai", tags=["AI Input Validation"])
ALLOWED_MIME = {"image/jpeg": ".jpg", "image/png": ".png"}
@router.post("/upload")
async def upload_for_ai(file: UploadFile = File(...), user: User = Depends(current_user)):
    if file.content_type not in ALLOWED_MIME:
        raise HTTPException(415, "Tipe file harus image/jpeg atau image/png")
    max_bytes = settings.max_file_size_mb * 1024 * 1024
    content = await file.read(max_bytes + 1)
    if not content:
        raise HTTPException(422, "File kosong")
    if len(content) > max_bytes:
        raise HTTPException(413, f"Ukuran file maksimal {settings.max_file_size_mb} MB")
    # Verify magic bytes instead of trusting the client-provided MIME type alone.
    if file.content_type == "image/jpeg" and not content.startswith(b"\xff\xd8\xff"):
        raise HTTPException(415, "Konten tidak sesuai dengan MIME JPEG")
    if file.content_type == "image/png" and not content.startswith(b"\x89PNG\r\n\x1a\n"):
        raise HTTPException(415, "Konten tidak sesuai dengan MIME PNG")
    # Intentionally not persisted or OCR-processed in this scaffold.
    return {"accepted": True, "filename": Path(file.filename or "upload").name[:120], "size_bytes": len(content), "content_type": file.content_type, "message": "Validasi berhasil; OCR belum diimplementasikan."}
