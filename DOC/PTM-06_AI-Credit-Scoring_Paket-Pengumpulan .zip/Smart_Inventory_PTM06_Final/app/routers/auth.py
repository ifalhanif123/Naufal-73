from datetime import timedelta
from fastapi import APIRouter, Depends, HTTPException
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.database import get_db
from app.core.security import create_token
from app.core.config import settings
from app.dependencies import current_user
from app.models import User
from app.schemas import SignupIn, UserOut, TokenPair, RefreshIn
from app.services.auth import signup, login, refresh

router = APIRouter(prefix="/auth", tags=["Authentication"])
@router.post("/signup", response_model=UserOut, status_code=201)
async def register(data: SignupIn, db: AsyncSession = Depends(get_db)):
    return await signup(db, data)
@router.post("/login", response_model=TokenPair)
async def token(form: OAuth2PasswordRequestForm = Depends(), db: AsyncSession = Depends(get_db)):
    return await login(db, form.username, form.password)
@router.post("/refresh", response_model=TokenPair)
async def refresh_token(data: RefreshIn, db: AsyncSession = Depends(get_db)):
    return await refresh(db, data.refresh_token)
@router.get("/me", response_model=UserOut)
async def me(user: User = Depends(current_user)):
    return user
