from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.database import get_db
from app.dependencies import current_user
from app.models import User, Borrowing
from app.schemas import BorrowingIn, BorrowingStatusIn
from app.services.inventory import create_borrowing
router = APIRouter(prefix="/borrowings", tags=["Borrowings"])
@router.get("")
async def list_borrowings(db: AsyncSession=Depends(get_db), user: User=Depends(current_user)):
    rows = await db.scalars(select(Borrowing).where(Borrowing.owner_id == user.id).order_by(Borrowing.id.desc()).limit(200))
    return list(rows.all())
@router.post("", status_code=201)
async def add_borrowing(data: BorrowingIn, db: AsyncSession=Depends(get_db), user: User=Depends(current_user)):
    return await create_borrowing(db, user.id, data)
@router.patch("/{borrowing_id}/status")
async def set_status(borrowing_id: int, data: BorrowingStatusIn, db: AsyncSession=Depends(get_db), user: User=Depends(current_user)):
    obj = await db.scalar(select(Borrowing).where(Borrowing.id == borrowing_id, Borrowing.owner_id == user.id))
    if not obj: raise HTTPException(404, "Data tidak ditemukan")
    obj.status = data.status
    await db.commit(); await db.refresh(obj); return obj
