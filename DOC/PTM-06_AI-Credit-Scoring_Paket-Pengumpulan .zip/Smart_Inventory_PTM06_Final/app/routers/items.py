from fastapi import APIRouter, Depends, HTTPException, Response
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.database import get_db
from app.dependencies import current_user
from app.models import User
from app.repositories.items import list_for_owner, get_for_owner
from app.schemas import ItemIn, ItemOut, ItemUpdate
from app.services.inventory import create_item, update_item
router = APIRouter(prefix="/items", tags=["Inventory"])
@router.get("", response_model=list[ItemOut])
async def list_items(db: AsyncSession=Depends(get_db), user: User=Depends(current_user)):
    return await list_for_owner(db, user.id)
@router.post("", response_model=ItemOut, status_code=201)
async def add_item(data: ItemIn, db: AsyncSession=Depends(get_db), user: User=Depends(current_user)):
    return await create_item(db, user.id, data)
@router.get("/{item_id}", response_model=ItemOut)
async def get_item(item_id: int, db: AsyncSession=Depends(get_db), user: User=Depends(current_user)):
    item = await get_for_owner(db, item_id, user.id)
    if not item: raise HTTPException(404, "Data tidak ditemukan")
    return item
@router.put("/{item_id}", response_model=ItemOut)
async def put_item(item_id: int, data: ItemUpdate, db: AsyncSession=Depends(get_db), user: User=Depends(current_user)):
    return await update_item(db, user.id, item_id, data)
@router.delete("/{item_id}", status_code=204)
async def delete_item(item_id: int, db: AsyncSession=Depends(get_db), user: User=Depends(current_user)):
    item = await get_for_owner(db, item_id, user.id)
    if not item: raise HTTPException(404, "Data tidak ditemukan")
    await db.delete(item); await db.commit(); return Response(status_code=204)
