from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.database import get_db
from app.dependencies import current_user
from app.models import User, StockTransaction
from app.schemas import TransactionIn
from app.services.inventory import create_transaction
router = APIRouter(prefix="/transactions", tags=["Stock Transactions"])
@router.get("")
async def list_transactions(db: AsyncSession=Depends(get_db), user: User=Depends(current_user)):
    rows = await db.scalars(select(StockTransaction).where(StockTransaction.owner_id == user.id).order_by(StockTransaction.id.desc()).limit(200))
    return list(rows.all())
@router.post("", status_code=201)
async def add_transaction(data: TransactionIn, db: AsyncSession=Depends(get_db), user: User=Depends(current_user)):
    return await create_transaction(db, user.id, data)
