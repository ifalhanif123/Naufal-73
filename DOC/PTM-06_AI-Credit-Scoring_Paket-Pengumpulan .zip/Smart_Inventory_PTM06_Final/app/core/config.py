from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_name: str = "Smart Inventory API"
    environment: str = "development"
    database_url: str = "postgresql+asyncpg://postgres:change_me@localhost:5432/smart_inventory"
    secret_key: str = "CHANGE_THIS_SECRET_BEFORE_RUNNING"
    algorithm: str = "HS256"
    access_token_expire_minutes: int = 30
    refresh_token_expire_days: int = 7
    max_file_size_mb: int = 5
    upload_dir: str = "./uploads"
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

settings = Settings()
