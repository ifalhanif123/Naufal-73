from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.models import Item

async def list_for_owner(db: AsyncSession, owner_id: int):
    result = await db.scalars(select(Item).where(Item.owner_id == owner_id).order_by(Item.id))
    return list(result.all())
async def get_for_owner(db: AsyncSession, item_id: int, owner_id: int):
    return await db.scalar(select(Item).where(Item.id == item_id, Item.owner_id == owner_id))
