from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.security import hash_password, verify_password, create_token_pair, decode_token
from app.models import User
from app.schemas import SignupIn
from jose import JWTError

async def signup(db: AsyncSession, data: SignupIn):
    exists = await db.scalar(select(User).where(User.email == data.email.lower()))
    if exists:
        raise HTTPException(status_code=409, detail="Email sudah terdaftar")
    user = User(email=data.email.lower(), full_name=data.full_name.strip(), password_hash=hash_password(data.password))
    db.add(user); await db.commit(); await db.refresh(user)
    return user

async def login(db: AsyncSession, email: str, password: str):
    user = await db.scalar(select(User).where(User.email == email.lower()))
    if not user or not user.is_active or not verify_password(password, user.password_hash):
        raise HTTPException(status_code=401, detail="Email atau kata sandi salah", headers={"WWW-Authenticate":"Bearer"})
    return create_token_pair(str(user.id))

async def refresh(db: AsyncSession, token: str):
    try:
        payload = decode_token(token)
        if payload.get("type") != "refresh": raise ValueError("wrong token type")
        uid = int(payload["sub"])
    except (JWTError, ValueError, TypeError, KeyError):
        raise HTTPException(status_code=401, detail="Refresh token tidak valid atau kedaluwarsa")
    user = await db.scalar(select(User).where(User.id == uid, User.is_active.is_(True)))
    if not user: raise HTTPException(status_code=401, detail="Pengguna tidak aktif")
    # Scaffold limitation: stateless refresh token is not revocable/rotated. See security audit.
    from datetime import timedelta
    from app.core.security import create_token
    from app.core.config import settings
    return {"access_token": create_token(str(user.id), "access", timedelta(minutes=settings.access_token_expire_minutes)), "refresh_token": token, "token_type":"bearer"}
