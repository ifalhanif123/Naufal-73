from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.models import Item, StockTransaction, Borrowing, Prediction
from app.repositories.items import get_for_owner
from app.schemas import ItemIn, ItemUpdate, TransactionIn, BorrowingIn, ForecastIn

async def create_item(db: AsyncSession, owner_id: int, data: ItemIn):
    duplicate = await db.scalar(select(Item).where(Item.owner_id == owner_id, Item.sku == data.sku))
    if duplicate: raise HTTPException(status_code=409, detail="SKU sudah digunakan")
    item = Item(owner_id=owner_id, **data.model_dump())
    db.add(item); await db.commit(); await db.refresh(item); return item

async def update_item(db: AsyncSession, owner_id: int, item_id: int, data: ItemUpdate):
    item = await get_for_owner(db, item_id, owner_id)
    if not item: raise HTTPException(status_code=404, detail="Data tidak ditemukan")
    values = data.model_dump(exclude_unset=True)
    if "sku" in values:
        duplicate = await db.scalar(select(Item).where(Item.owner_id == owner_id, Item.sku == values["sku"], Item.id != item_id))
        if duplicate: raise HTTPException(status_code=409, detail="SKU sudah digunakan")
    for key, value in values.items(): setattr(item, key, value)
    await db.commit(); await db.refresh(item); return item

async def create_transaction(db: AsyncSession, owner_id: int, data: TransactionIn):
    item = await get_for_owner(db, data.item_id, owner_id)
    if not item: raise HTTPException(status_code=404, detail="Barang tidak ditemukan")
    if data.kind == "OUT" and item.quantity < data.quantity: raise HTTPException(status_code=422, detail="Stok tidak mencukupi")
    item.quantity += data.quantity if data.kind == "IN" else -data.quantity
    tx = StockTransaction(owner_id=owner_id, **data.model_dump())
    db.add(tx); await db.commit(); await db.refresh(tx); return tx

async def create_borrowing(db: AsyncSession, owner_id: int, data: BorrowingIn):
    item = await get_for_owner(db, data.item_id, owner_id)
    if not item: raise HTTPException(status_code=404, detail="Barang tidak ditemukan")
    if item.quantity < data.quantity: raise HTTPException(status_code=422, detail="Stok tidak mencukupi")
    item.quantity -= data.quantity
    obj = Borrowing(owner_id=owner_id, **data.model_dump())
    db.add(obj); await db.commit(); await db.refresh(obj); return obj
