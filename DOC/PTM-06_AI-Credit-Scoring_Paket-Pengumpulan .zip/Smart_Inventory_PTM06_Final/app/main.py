from contextlib import asynccontextmanager
from fastapi import FastAPI
from app.core.config import settings
from app.core.database import engine
from app.models.entities import Base
from app.routers import auth, items, transactions, borrowings, predictions, ai_upload

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Convenience for coursework/local demo only; use Alembic migrations in production.
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield
    await engine.dispose()

app = FastAPI(title=settings.app_name, version="0.1.0", lifespan=lifespan)
for router in (auth.router, items.router, transactions.router, borrowings.router, predictions.router, ai_upload.router):
    app.include_router(router)
@app.get("/health", tags=["System"])
async def health(): return {"status":"ok"}
