# Test plan to execute

Do not mark these as passed until run against a configured PostgreSQL database.

1. Signup duplicate email returns 409.
2. Login with wrong password returns 401.
3. `/auth/me` without Bearer token returns 401.
4. Refresh with an access token instead of refresh token returns 401.
5. User A cannot GET/PUT/DELETE User B's item ID; expected scaffold result is 404 (lecturer worksheet says 403, so align implementation/status code with rubric if required).
6. Transaction with an item owned by another user returns 404.
7. OUT transaction greater than available quantity returns 422.
8. Forecast with fewer than 6 values, negative values, excessive horizon, or huge values is rejected by schema.
9. Upload unsupported MIME returns 415; upload over 5MB returns 413; fake JPEG/PNG magic bytes returns 415.
10. Verify returned user profile never contains password hash or tokens.
