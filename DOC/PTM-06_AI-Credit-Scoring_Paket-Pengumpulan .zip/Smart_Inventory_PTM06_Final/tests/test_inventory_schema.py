"""Focused schema validation tests for the Smart Inventory API scaffold."""
import pytest
from pydantic import ValidationError
from app.schemas import ForecastIn, ItemIn, SignupIn


def test_forecast_accepts_six_months_of_nonnegative_sales():
    payload = ForecastIn(item_id=1, monthly_sales=[10, 12, 9, 15, 13, 18], horizon=1)
    assert payload.item_id == 1
    assert len(payload.monthly_sales) == 6


def test_forecast_rejects_negative_sales():
    with pytest.raises(ValidationError):
        ForecastIn(item_id=1, monthly_sales=[10, 12, 9, 15, 13, -1], horizon=1)


def test_forecast_rejects_too_short_history():
    with pytest.raises(ValidationError):
        ForecastIn(item_id=1, monthly_sales=[10, 12, 9, 15, 13], horizon=1)


def test_item_rejects_negative_quantity():
    with pytest.raises(ValidationError):
        ItemIn(name="Kertas A4", sku="KRT-A4", quantity=-1, unit="rim")


def test_signup_rejects_short_password():
    with pytest.raises(ValidationError):
        SignupIn(email="demo@example.com", password="short", full_name="Demo User")
