# OWASP API Security Review (self-audit scaffold)

Scope is based on the LKP-PTM-06 focus list and code in this repository. This is a **code-review checklist**, not proof of a completed penetration test.

| Area | Risk if omitted | Mitigation in scaffold | Verification still required |
|---|---|---|---|
| API1: Broken Object Level Authorization | User may read/change another user's records by changing an ID | Queries for items, transactions, borrowings, predictions include `owner_id`; item operations only fetch owner-scoped records | Add two-user negative tests for every ID-based endpoint; worksheet asks 403, scaffold intentionally returns 404 to avoid object enumeration; align status with lecturer rubric |
| API2: Broken Authentication | Weak/plaintext passwords or invalid tokens accepted | Argon2 password hashing; JWT signature/expiry/type validation; 30-min access tokens; 7-day refresh token | Test expired/wrong-type token, wrong password, disabled user; refresh-token revocation/rotation is not implemented |
| API3: Broken Object Property Level Authorization | Sensitive fields leaked or writable | Responses use schemas for user profile/item; password hash excluded from API responses | Review every future response schema and mass-assignment field |
| API4: Unrestricted Resource Consumption | Huge payload/file can exhaust memory or CPU | Pydantic length/range constraints, query limits, upload reads at most 5MB + 1 byte, MIME allowlist and magic-byte check | Add rate limiting, request timeouts, DB statement timeout, and deployment-level body-size limits |
| API5: Broken Function Level Authorization | Ordinary user reaches admin actions | No admin-only route is exposed in this scaffold | Implement explicit role checks before adding admin routes; test privilege escalation |
| API8: Security Misconfiguration | Debug/secrets/default settings exposed | secrets/config read from environment; `.env` ignored by Git | Generate a strong secret, restrict CORS in deployment, disable debug, manage secrets outside repository |
| AI input validation | Malicious/oversized uploads or invalid forecasting data | Upload accepts JPEG/PNG only, checks 5MB limit and magic bytes; forecasting numeric data bounded by schema | Upload endpoint is validation-only; no OCR is run. Add rate limit and malware scanning if persistence is introduced |

## Anti-BOLA pattern

Fetch the resource with both the object ID and authenticated owner ID, e.g. `select(Item).where(Item.id == item_id, Item.owner_id == user.id)`. Do not fetch by ID and trust a client-supplied `owner_id`. For related resources, verify the parent item also belongs to the same owner.

## Known limitations / actions

1. PTM-05 OpenAPI was not provided, so route coverage must be reconciled with `openapi.yaml`.
2. Refresh token is stateless and reusable until expiry. Add server-side hashed token identifiers, rotation, and revocation before production use.
3. No rate limiting, email verification, password reset, admin RBAC, or audit logging is included.
4. Prediction model is a baseline trained per request on a short history. Evaluate chronological holdout MAE/RMSE and compare with a naive baseline; do not use outputs as purchase orders without human review.
5. Run automated tests and Postman scenarios before marking items as verified.
