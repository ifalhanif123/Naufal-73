# Postman collection

Import `postman-collection.json` into Postman. Set the `base_url` variable to `http://127.0.0.1:8000` and use the auth requests to obtain a bearer token before testing protected inventory routes.

The collection is a starting point. Run it against the local API and record actual outcomes; collection presence alone does not mean all endpoints have been verified.
