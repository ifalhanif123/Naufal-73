# PTM-06 Prompt Log (draft based on scaffold generation)

> The assignment requires the team's actual AI interaction history. The rows below are a structured draft of prompts used to design this scaffold; edit the tool/version and evaluation after checking your own interaction history. Do not claim this file is a verbatim transcript.

## Session 1 — Modular backend
**Prompt summary:** Build a FastAPI backend using Router → Service → Repository, SQLAlchemy 2.0 async, PostgreSQL, Pydantic v2, and inventory resources. Keep secrets in environment variables and separate DB access from business logic.

**Initial concern / iteration:** The PTM-05 OpenAPI contract was not attached, so the generated endpoints cannot be confirmed as an exact match.

**Follow-up prompt:** Treat the supplied LKP-PTM-06 as requirements, create an explicit starter API for users, items, stock transactions, borrowings, and Random Forest forecasts, and document all assumptions that must be reconciled against the actual OpenAPI contract.

**Evaluation:** Useful as a modular scaffold; must be compared with the team's actual PTM-05 contract and models before submission.

## Session 2 — JWT and OWASP
**Prompt summary:** Implement signup/login/refresh/me using JWT access/refresh tokens, secure password hashing, owner-scoped CRUD, upload MIME/size validation, and an OWASP API Security review.

**Initial concern / iteration:** Refresh token rotation/revocation and admin role policies require production-grade follow-up; ownership status code may differ from the lecturer's 403 requirement.

**Follow-up prompt:** Validate JWT type/expiry, hash passwords with Argon2, limit image uploads to 5MB JPEG/PNG, verify magic bytes, and ensure queries filter by authenticated owner ID. Record limitations rather than claiming a complete audit.

**Evaluation:** Starter mitigations are present in code; test results are not asserted here. Execute Postman tests and two-user authorization tests before marking verified.

## Manual verification record (fill after testing)
- AI tool and version: ____________________
- Date/session: ____________________
- Routes tested and result: ____________________
- Revisions made manually: ____________________
- Team member(s) who verified: ____________________
