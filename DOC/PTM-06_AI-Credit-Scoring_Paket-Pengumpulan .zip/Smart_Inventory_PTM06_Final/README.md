# PTM-06 — Smart Inventory & Stock Demand Forecasting API

Starter deliverable for the PTM-06 Backend API & Security practical. Stack: **FastAPI**, **PostgreSQL**, **SQLAlchemy 2.0 async**, **Pydantic v2**, JWT access/refresh tokens, and a Random Forest demand-forecast endpoint.

> **Important:** This is a scaffold/reference implementation. The OpenAPI PTM-05 file and actual PTM-05 database models were not included with the provided LKP file, so endpoints and domain fields below are explicit assumptions. Compare and align them with your team's `openapi.yaml` before submission. The worksheet identity, team/NIM, Git URL, and actual test evidence must be filled by the student/team.

## 1. Quick start

1. Install Python 3.11+ and PostgreSQL.
2. Copy `.env.example` to `.env` and set a unique `SECRET_KEY` and your local database URL.
3. Create a virtual environment and install dependencies:
   ```bash
   python -m venv .venv
   # Windows: .venv\Scripts\activate
   # Linux/macOS: source .venv/bin/activate
   pip install -r requirements.txt
   ```
4. Run the API:
   ```bash
   uvicorn app.main:app --reload
   ```
5. Open `http://127.0.0.1:8000/docs`.

Tables are created automatically on startup for local practical use. For production, use Alembic migrations instead. The default database URL expects PostgreSQL; SQLite is not the target configuration.

## 2. Routes

- `POST /auth/signup`, `POST /auth/login`, `POST /auth/refresh`, `GET /auth/me`
- `GET/POST /items`, `GET/PUT/DELETE /items/{item_id}`
- `GET/POST /transactions`
- `GET/POST /borrowings`, `PATCH /borrowings/{borrowing_id}/status`
- `POST /predictions/forecast` — trains a small RandomForestRegressor from supplied historical monthly values; this is a demo and needs real data/evaluation before operational use.
- `POST /ai/upload` — optional image-upload validation example (JPEG/PNG, maximum 5 MB); it does not perform OCR.

All item, transaction, borrowing, and prediction records are scoped to the authenticated owner. Admin/role management is not fully implemented in this scaffold; see `docs/security/owasp-audit.md` and assumptions in the worksheet.

## 3. Example requests

Sign up:
```json
POST /auth/signup
{"email":"demo@example.com","password":"StrongPass123!","full_name":"Demo User"}
```
Login uses OAuth2 form fields `username` (email) and `password` at `/auth/login`. Copy `access_token` into Swagger's Authorize dialog as a Bearer token.

Forecast:
```json
POST /predictions/forecast
{"item_id":1,"monthly_sales":[12,15,14,20,18,22,25,24],"horizon":1}
```

## 4. Security notes

- Passwords are Argon2-hashed via `pwdlib`; plaintext passwords are never stored.
- Access token lifetime is 30 minutes; refresh token lifetime is 7 days and token type is checked.
- `SECRET_KEY` is read from environment variables only.
- Object-level ownership is checked before reading/updating/deleting user-owned records.
- Upload size and MIME type are checked before reading the full upload; filenames supplied by clients are not used as paths.
- The input forecast uses validated numeric values; do not treat text sanitization as a substitute for model/data validation.
- A simple JWT refresh token is not a revocable session store. Production should store hashed refresh-token identifiers, rotate tokens, and revoke on logout/password change.

## 5. Before submission

- Align routes/schema with your team's PTM-05 `openapi.yaml` and database models.
- Run tests and record the actual results in the worksheet; do not claim tests passed unless you ran them.
- Update student/team identity, Git remote URL, and commit using the lecturer's exact required message:
  `feat(backend): implement JWT auth, CRUD endpoints, OWASP patches [PTM-06]`

## 6. Tests and verification

Run the schema-focused tests from this folder after installing `requirements.txt`:

```bash
pytest -q
```

These tests cover request-schema validation only. They do not replace database integration tests, two-user anti-BOLA tests, or end-to-end Postman verification. The source scaffold has not been declared production-ready solely on the basis of these unit tests.

## 7. Submission contents

- `LKP-PTM-06-IMWAD_TERISI_LENGKAP.docx` and matching PDF worksheet
- `app/` modular FastAPI scaffold
- `tests/test_inventory_schema.py`
- `.env.example`
- `docs/postman/postman-collection.json`
- `docs/security/owasp-audit.md`
- `docs/prompt-log/ptm-06-prompt-log.md`

The PTM-05 `openapi.yaml` and a Git remote were not provided. Align the routes to the team's actual contract and add the Git URL before final submission if required by the lecturer.
